//
//  main.m
//  里氏替换原则
//
//  Created by ligf on 13-11-26.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Employee.h"
#import "Director.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        /*
        //调用Employee类的calculateSalary方法
        Employee *employee = [[Employee alloc] init];
        [employee calculateSalary:@"张三"];
        [employee release];
         */
        // 如果Director类(子类)重写了计算工资的方法,则调用子类的calculateSalary方法
        Employee *employee = [[Director alloc] init];  //将所有父类出现的地方都替换成子类
        [employee calculateSalary:@"张三"];
        [employee release];
    }
    return 0;
}

