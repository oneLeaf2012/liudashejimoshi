//
//  Employee.m
//  LiskovSubstitutionPrinciple
//
//  Created by ligf on 13-11-26.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import "Employee.h"

@implementation Employee

- (void)calculateSalary:(NSString *)name
{
    NSLog(@"%@的工资是100",name);
}

@end
