//
//  Director.m
//  LiskovSubstitutionPrinciple
//
//  Created by ligf on 13-11-26.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import "Director.h"

@implementation Director

- (void)calculateSalary:(NSString *)name
{
    NSLog(@"总监%@的工资是10000",name);
}

- (void)duty
{
    NSLog(@"总监的职责是管理");
}

@end
