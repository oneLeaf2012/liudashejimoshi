//
//  Director.h
//  LiskovSubstitutionPrinciple
//
//  Created by ligf on 13-11-26.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import "Employee.h"

@interface Director : Employee

// 职责
- (void)duty;

@end
