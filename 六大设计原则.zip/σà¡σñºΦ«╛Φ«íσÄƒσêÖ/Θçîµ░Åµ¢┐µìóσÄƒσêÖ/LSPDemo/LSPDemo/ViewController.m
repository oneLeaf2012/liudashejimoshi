//
//  ViewController.m
//  LSPDemo
//
//  Created by shuzhenguo on 2017/7/26.
//  Copyright © 2017年 shuzhenguo. All rights reserved.
//IOS设计模式的六大设计原则之里氏替换原则(LSP,Liskov Substitution Principle)

/*
 
 定义
 
 里氏替换原则的定义有两种，据说是由麻省理工的一位姓里的女士所提出，因此以其名进行命名。
 
 定义1：如果对一个类型为T1的对象o1，都有类型为T2的对象o2，使得以T1所定义的程序P中在o1全都替换成o2时，程序的行为不发生任何变化，那么T2为T1的子类。
 定义2:所有引用父类的地方都必须能够透明地使用其子类对象。
 定义解读
 
 其实两个定义所表达的意思都相同，就是在所有父类出现的地方，子类都可以出现，并且将父类对象替换为子类对象的时候，程序不会抛出任何异常或者错误，因此我们需要注意的是，尽量不要重载或者重写父类的方法(抽象方法除外)，因为这样可能会改变父类原有的行为。
 
 优点
 
 代码共享，减少创建类的工作量，每个子类都拥有父类的所有属性和方法；
     提高代码的可扩张性；
 提高产品或项目的开放性。
 缺点
 
 继承是入侵性的，拥有父类的属性和方法；
 降低代码的灵活性，必须拥有父类的属性和方法；
 增强耦合性，父类属性或方法改变，需要考虑子类。
 
 
 //
 
 
 相关代码查看 ezfm  里的 BaseViewController

 方法 addNavibackItem 
 
 在到继承BaseViewController里找到SetUpTheViewController
 
 -(void)backPressed:(id)sender
 
 */

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
