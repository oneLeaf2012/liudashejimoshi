//
//  Director.h
//  DependenceInversionPrinciple
//
//  Created by ligf on 13-11-28.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "EmployeeDelegate.h"

@interface Director : NSObject<EmployeeDelegate>

@property(nonatomic, copy) NSString *strName;  // 姓名

//- (void)calculateSalary;

@end
