//
//  Director.m
//  DependenceInversionPrinciple
//
//  Created by ligf on 13-11-28.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import "Director.h"

@implementation Director

@synthesize strName = _strName;

- (void)calculateSalary
{
    NSLog(@"%@总监的工资是10000",_strName);
}

- (void)dealloc
{
    [_strName release];
    
    [super dealloc];
}

@end
