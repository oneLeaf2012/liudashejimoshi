//
//  main.m
//  依赖倒置原则
//
//  Created by ligf on 13-11-28.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SalaryManage.h"
#import "Director.h"
#import "Manager.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        /* 原始做法
        Director *director = [[Director alloc] init];
        director.strName  = @"张三";
        SalaryManage *salaryManage = [[SalaryManage alloc] init];
        [salaryManage calculateSalary:director];
        [director release];
        [salaryManage release];
         */
        // 遵守依赖倒置原则的做法
        Director *director = [[Director alloc] init];
        director.strName  = @"张三";
        Manager *manager = [[Manager alloc] init];
        manager.strName  = @"李四";
        SalaryManage *salaryManage = [[SalaryManage alloc] init];
        [salaryManage calculateSalary:director];
        [salaryManage calculateSalary:manager];
        [director release];
        [manager release];
        [salaryManage release];
    }
    return 0;
}

