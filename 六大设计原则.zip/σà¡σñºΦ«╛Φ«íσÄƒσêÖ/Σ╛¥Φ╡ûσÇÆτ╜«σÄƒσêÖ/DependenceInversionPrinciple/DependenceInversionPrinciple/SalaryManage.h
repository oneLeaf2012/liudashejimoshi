//
//  SalaryManage.h
//  DependenceInversionPrinciple
//
//  Created by ligf on 13-11-28.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "EmployeeDelegate.h"
#import "Director.h"

@interface SalaryManage : NSObject

//- (void)calculateSalary:(Director *)director;  // 原始做法
- (void)calculateSalary:(id<EmployeeDelegate>)employee;  // 遵守依赖倒置原则的做法

@end
