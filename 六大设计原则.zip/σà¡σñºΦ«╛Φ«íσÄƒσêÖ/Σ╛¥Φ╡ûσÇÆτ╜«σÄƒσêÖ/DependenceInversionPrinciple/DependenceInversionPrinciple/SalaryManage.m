//
//  SalaryManage.m
//  DependenceInversionPrinciple
//
//  Created by ligf on 13-11-28.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import "SalaryManage.h"

@implementation SalaryManage

/*
- (void)calculateSalary:(Director *)director
{
    [director calculateSalary];
}
 */

- (void)calculateSalary:(id<EmployeeDelegate>)employee
{
    [employee calculateSalary];
}

@end
