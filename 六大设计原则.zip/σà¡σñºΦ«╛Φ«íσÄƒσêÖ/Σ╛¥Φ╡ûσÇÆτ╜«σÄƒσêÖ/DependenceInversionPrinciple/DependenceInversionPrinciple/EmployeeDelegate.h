//
//  EmployeeDelegate.h
//  DependenceInversionPrinciple
//
//  Created by ligf on 13-11-28.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol EmployeeDelegate <NSObject>

- (void)calculateSalary;

@end
