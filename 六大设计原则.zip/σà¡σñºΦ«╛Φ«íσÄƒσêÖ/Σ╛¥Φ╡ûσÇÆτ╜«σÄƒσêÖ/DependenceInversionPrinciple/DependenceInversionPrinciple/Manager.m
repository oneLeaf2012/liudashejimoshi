//
//  Manager.m
//  DependenceInversionPrinciple
//
//  Created by ligf on 13-11-28.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import "Manager.h"

@implementation Manager

@synthesize strName = _strName;

- (void)calculateSalary
{
    NSLog(@"%@经理的工资是1000",_strName);
}

- (void)dealloc
{
    [_strName release];
    
    [super dealloc];
}

@end
