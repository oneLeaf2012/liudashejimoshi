//
//  ViewController.m
//  OCPDemo
//
//  Created by shuzhenguo on 2017/7/26.
//  Copyright © 2017年 shuzhenguo. All rights reserved.
//
/*
 IOS设计模式的六大设计原则之开放-关闭原则(OCP,Open-Close Principle)
 
 定义
 
 　　一个软件实体(如类、模块、函数)应当对扩展开放，对修改关闭。
 
 定义解读
 
 　　在项目开发的时候，都不能指望需求是确定不变化的，大部分情况下，需求是变化的。那么如何应对需求变化的情况？这就是开放-关闭原则要谈的。
 
 　　开放-封闭原则的思想就是设计的时候，尽量让设计的类做好后就不再修改，如果有新的需求，通过新加类的方式来满足，而不去修改现有的类(代码)。那么在实际的项目开发中，是否能做到绝对的对修改关闭呢？答案一般也是否定的。既然这样，那么就要求我们在开发前，去找出变化点，然后针对变化点构造抽象，隔离出这些变化。由此可见，实现开闭原则关键是抽象。
 
 优点
 
 具有灵活性，通过拓展一个功能模块即可实现功能的扩充，不需修改内部代码。
 具有稳定性，表现在基本功能类不允许被修改，使得被破坏的程度大大下降。
 
 */

#define kDeviceHeight [UIScreen mainScreen].bounds.size.height
#define kDeviceWidth  [UIScreen mainScreen].bounds.size.width

#import "ViewController.h"
#import "UILabel+LXAdd.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //回归项目
    
    //主持人详情页 里的内容简介 info
    //最初的需求，内容简介为固定的行数，3行如下代码
    
    UILabel *lable=[[UILabel alloc]init];
    lable.frame=CGRectMake(0, 100, kDeviceWidth, 150);
    lable.text=@"一个软件实体(如类、模块、函数)应当对扩展开放，对修改关闭。具有灵活性，通过拓展一个功能模块即可实现功能的扩充，不需修改内部代码。具有稳定性，表现在基本功能类不允许被修改，使得被破坏的程度大大下降。";
    lable.numberOfLines=3;
    [self.view addSubview:lable];

   
    
    //后期呢，需要文字适配高度，这个时候，我又不想更改太多本类的代码，所以用类扩展，进行操作，来符合开发-关闭原则
    
    CGSize labSize = [lable getLableSizeWithMaxWidth:kDeviceWidth];
    
    
    lable.frame=CGRectMake(lable.frame.origin.x, lable.frame.origin.y, kDeviceWidth, labSize.height);
    

    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
