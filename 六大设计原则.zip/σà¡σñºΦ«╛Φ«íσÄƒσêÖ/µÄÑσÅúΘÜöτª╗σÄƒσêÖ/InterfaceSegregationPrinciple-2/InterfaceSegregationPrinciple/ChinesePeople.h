//
//  ChinesePeople.h
//  InterfaceSegregationPrinciple
//
//  Created by ligf on 13-11-29.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IAnimal.h"
#import "IPeople.h"

@interface ChinesePeople : NSObject

@property (nonatomic,assign) id<IAnimal> animalDelegate;
@property (nonatomic,assign) id<IPeople> peopleDelegate;

@end
