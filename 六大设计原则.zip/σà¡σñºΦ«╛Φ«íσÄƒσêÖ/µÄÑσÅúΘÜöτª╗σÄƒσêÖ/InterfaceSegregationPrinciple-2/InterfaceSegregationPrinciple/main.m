//
//  main.m
//  接口隔离原则
//
//  Created by ligf on 13-11-29.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ChinesePeople.h"
#import "People.h"

int main(int argc, const char * argv[])
{
    @autoreleasepool {
        ChinesePeople *chinesePeople = [[ChinesePeople alloc] init];
        People *people = [[People alloc] init];
        
        chinesePeople.animalDelegate = people;
        chinesePeople.peopleDelegate = people;
        
        [chinesePeople work];
        [chinesePeople eat];
        [chinesePeople walk];
        [chinesePeople release];
        [people release];
    }
    return 0;
}

