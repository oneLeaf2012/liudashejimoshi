//
//  IAnimal.h
//  InterfaceSegregationPrinciple
//
//  Created by ligf on 13-11-29.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol IAnimal <NSObject>

//- (void)work;  // 使用接口隔离原则，将该方法放到其他接口
//- (void)fly;  // 使用接口隔离原则，将该方法放到其他接口
@optional
- (void)walk;
@required
- (void)eat;

@end
