//
//  ChinesePeople.m
//  InterfaceSegregationPrinciple
//
//  Created by ligf on 13-11-29.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import "ChinesePeople.h"

@implementation ChinesePeople
@synthesize animalDelegate = _animalDelegate;
@synthesize peopleDelegate = _peopleDelegate;

- (void)work
{
//    [_animalDelegate work];
    [_peopleDelegate work];
}

//- (void)fly
//{
//    [_animalDelegate fly];
//}

- (void)walk
{
    [_animalDelegate walk];
}

- (void)eat
{
    [_animalDelegate eat];
}

@end
