//
//  Bird.m
//  InterfaceSegregationPrinciple
//
//  Created by ligf on 13-11-29.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import "Bird.h"

@implementation Bird

//- (void)work
//{
//    NSLog(@"I am working");
//}

- (void)fly
{
    NSLog(@"I am flying");
}

- (void)walk
{
    NSLog(@"I am walking");
}

- (void)eat
{
    NSLog(@"I am eating");
}

@end
