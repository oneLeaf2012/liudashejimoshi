//
//  Parrot.m
//  InterfaceSegregationPrinciple
//
//  Created by ligf on 13-11-29.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import "Parrot.h"

@implementation Parrot
@synthesize animalDelegate = _animalDelegate;
@synthesize birdDelegate = _birdDelegate;

//- (void)work
//{
//    [_animalDelegate work];
//}

- (void)fly
{
//    [_animalDelegate fly];
    [_birdDelegate fly];
}

- (void)walk
{
    [_animalDelegate walk];
}

- (void)eat
{
    [_animalDelegate eat];
}

@end
