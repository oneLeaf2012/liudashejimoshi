//
//  main.m
//  ISPDemo
//
//  Created by shuzhenguo on 2017/7/26.
//  Copyright © 2017年 shuzhenguo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
