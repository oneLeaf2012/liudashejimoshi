//
//  ViewController.m
//  LODDemo
//
//  Created by shuzhenguo on 2017/7/26.
//  Copyright © 2017年 shuzhenguo. All rights reserved.
//IOS设计模式的六大设计原则之迪米特法则(LOD,Law Of Demeter)

/*
 定义
 
 狭义的迪米特法则定义：也叫最少知识原则(LKP，Least Knowledge Principle)。如果两个类不必彼此直接通信，那么这两个类就不应当发生直接的相互作用。如果其中的一个类需要调用另一个类的某一个方法的话，可以通过第三者转发这个调用。
 
 广义的迪米特法则定义：一个模块设计得好坏的一个重要的标志就是该模块在多大的程度上将自己的内部数据与实现有关的细节隐藏起来。信息的隐藏非常重要的原因在于，它可以使各个子系统之间脱耦，从而允许它们独立地被开发、优化、使用阅读以及修改。
 
 定义解读
 
 迪米特法则通常被表述为：Only talk to your immediate friends ( 只和离你最近的朋友进行交互)。什么是最近的朋友？我们知道，每个对象都会与其他对象之间有耦合关系，只要两个对象之间有耦合关系，我们就说这两个对象之间是朋友关系。耦合的方式很多，如依赖、关联、组合、聚合等。其中，我们称出现在成员变量、方法参数、方法返回值中的类为最近的朋友，而出现在局部变量中的类则不是最近的朋友。迪米特法则是很好的解耦合手段之一。在网上看到的比较形象的说明这个法则的示例：
 
 如果你想让你的狗狗跑的话，你会对狗狗说还是对四条狗腿说？
 
 如果你去店里买东西，你会把钱交给店员，还是会把钱包交给店员让他自己拿？
 
 优点
 
 迪米特法则使对象之间的耦合降到最小，符合高内聚低耦合的特性，从而使得类具有很好的可读性和可维护性。
 
 后面介绍的设计模式中，外观模式（Facade）和中介者模式（Mediator），都是迪米特法则应用的例子。
 
 */



/*
 
 用协议实现多继承，将BaseViewController
 
 */

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
