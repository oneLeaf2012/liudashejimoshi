//
//  Inmates.m
//  LawOfDemeter
//
//  Created by ligf on 13-12-2.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import "Inmates.h"

@implementation Inmates

- (void)weAreFriend
{
    NSLog(@"狱友说：我们是狱友...");
}

@end
