//
//  InmatesDelegate.h
//  LawOfDemeter2
//
//  Created by ligf on 13-12-2.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol InmatesDelegate <NSObject>

- (void)weAreFriend;

@end
