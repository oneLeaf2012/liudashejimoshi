//
//  Family.m
//  LawOfDemeter
//
//  Created by ligf on 13-12-2.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import "Family.h"

@implementation Family

- (void)visitPrisoner:(Prisoners *)prisoners inmates:(id<InmatesDelegate>)inmates
{
    //家人希望犯人与狱友互帮互助
    [prisoners helpEachOther];
    //狱友说，我们是狱友
    [inmates weAreFriend];
}

@end
