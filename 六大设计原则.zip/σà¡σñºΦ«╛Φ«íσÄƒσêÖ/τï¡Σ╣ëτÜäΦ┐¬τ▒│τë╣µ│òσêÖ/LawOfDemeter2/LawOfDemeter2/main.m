//
//  main.m
//  LawOfDemeter2
//
//  Created by ligf on 13-12-2.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "InmatesDelegate.h"
#import "Prisoners.h"
#import "Family.h"
#import "Inmates.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        Family *family = [[Family alloc] init];
        Prisoners *prisoners = [[Prisoners alloc] init];
        
        id<InmatesDelegate> inmates = [[Inmates alloc] init];
        
        [family visitPrisoner:prisoners inmates:inmates];
        
        [inmates release];
        [prisoners release];
        [family release];
    }
    return 0;
}

