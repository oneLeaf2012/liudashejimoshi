//
//  Prisoners.m
//  LawOfDemeter
//
//  Created by ligf on 13-12-2.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import "Prisoners.h"

@implementation Prisoners

- (void)helpEachOther
{
    NSLog(@"家人说：你和狱友之间应该互相帮助...");
}

@end
