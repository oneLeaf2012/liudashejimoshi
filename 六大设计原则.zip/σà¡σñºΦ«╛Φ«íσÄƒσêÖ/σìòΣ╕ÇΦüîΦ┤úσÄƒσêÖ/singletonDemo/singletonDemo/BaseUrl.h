//
//  BaseUrl.h
//  singleDemo
//
//  Created by shuzhenguo on 2017/7/25.
//  Copyright © 2017年 shuzhenguo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseUrl : NSObject
- (NSString *) getLoginUrl;
- (NSString *) getHomeUrl;

@end
