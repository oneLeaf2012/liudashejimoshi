//
//  UrlFormal.m
//  singletonDemo
//
//  Created by shuzhenguo on 2017/7/25.
//  Copyright © 2017年 shuzhenguo. All rights reserved.
//

#import "UrlFormal.h"

@implementation UrlFormal
- (NSString *) getFormal{
return @"我是正式的URL";
}


- (NSString *) getLoginUrl{
    return @"我是登录正式接口";
}

- (NSString *) getHomeUrl{
    return @"我是首页正式接口";
}

@end
