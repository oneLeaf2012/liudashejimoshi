//
//  BaseUrl.m
//  singleDemo
//
//  Created by shuzhenguo on 2017/7/25.
//  Copyright © 2017年 shuzhenguo. All rights reserved.
//

#import "BaseUrl.h"

@implementation BaseUrl

- (NSString *) getLoginUrl{

return @"BaseUrlLogin";
}
- (NSString *) getHomeUrl{

return @"BaseHomeUrl";
}
@end
