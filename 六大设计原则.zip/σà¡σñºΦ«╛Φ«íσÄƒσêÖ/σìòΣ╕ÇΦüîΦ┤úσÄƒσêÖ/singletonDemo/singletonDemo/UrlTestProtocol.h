//
//  UrlTestProtocol.h
//  singleDemo
//
//  Created by shuzhenguo on 2017/7/25.
//  Copyright © 2017年 shuzhenguo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseUrlProtocol.h"



@interface UrlTestProtocol : NSObject<BaseUrlProtocol>
- (NSString *) getLoginUrl;
- (NSString *) getHomeUrl;

@end
