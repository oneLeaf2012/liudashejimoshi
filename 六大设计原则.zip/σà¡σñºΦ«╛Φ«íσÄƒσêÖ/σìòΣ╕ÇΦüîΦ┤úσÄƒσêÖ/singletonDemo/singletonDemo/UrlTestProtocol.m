//
//  UrlTestProtocol.m
//  singleDemo
//
//  Created by shuzhenguo on 2017/7/25.
//  Copyright © 2017年 shuzhenguo. All rights reserved.
//

#import "UrlTestProtocol.h"

@implementation UrlTestProtocol

- (NSString *) getLoginUrl{
    return @"我是登录测试接口";
}

- (NSString *) getHomeUrl{
    return @"我是首页测试接口";
}

@end
