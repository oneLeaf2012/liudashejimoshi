//
//  UrlAddress.m
//  QYSDKCommon
//
//  Created by shuzhenguo on 14-4-15.
//  Copyright (c) 2014年 shuzhenguo. All rights reserved.
//

/*
 IOS设计模式的六大设计原则之单一职责原则(SRP,Single Responsibility Principle)
 
 定义
 　　就一个类而言，应该仅有一个引起它变化的原因。
 
 
 定义解读
 
 　　这是六大原则中最简单的一种，通俗点说，就是不存在多个原因使得一个类发生变化，也就是一个类只负责一种职责的工作。
 
 
 
 优点
 
 类的复杂度降低，一个类只负责一个功能，其逻辑要比负责多项功能简单的多；
 类的可读性增强，阅读起来轻松；
 可维护性强，一个易读、简单的类自然也容易维护；
 变更引起的风险降低，变更是必然的，如果单一职责原则遵守的好，当修改一个功能时，可以显著降低对其他功能的影响。
 
 
 
 
 
 
 
 */
#import "UrlAddress.h"

@interface UrlAddress()
{
    NSString* _url_prefix;
    NSString *_url_homeUrl;
    NSString *_url_loginUrl;
    NSString *_url_registeredUrl;
    
    
}
@end
@implementation UrlAddress


static UrlAddress* s_urlAddress = nil;

/*
 使用alloc方法初始化一个类的实例的时候，默认是调用了 allocWithZone 的方法。于是覆盖allocWithZone方法的原因已经很明显了：为了保持单例类实例的唯一性，需要覆盖所有会生成新的实例的方法，如果有人初始化这个单例类的时候不走[[Class alloc] init] ，而是直接 allocWithZone， 那么这个单例就不再是单例了，所以必须把这个方法也堵上
 */
// 重写+allocWithZone方法，保证永远都只为单例对象分配一次内存空间
+(instancetype)allocWithZone:(struct _NSZone *)zone
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (s_urlAddress == nil) {
            s_urlAddress = [super allocWithZone:zone];
        }
    });
    return s_urlAddress;
}

// 为了使实例易于外界访问 我们一般提供一个类方法
// 类方法命名规范 share类名|default类名|类名
+(instancetype)getInstance
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        s_urlAddress = [[self alloc] init];
    });
    return s_urlAddress;
}


// 为了严谨，也要重写copyWithZone 和 mutableCopyWithZone。

/*//copy在底层 会调用copyWithZone:
 
 */
-(id)copyWithZone:(NSZone *)zone
{
    return s_urlAddress;
}

+ (id)copyWithZone:(struct _NSZone *)zone
{
    return  s_urlAddress;
}

//如果想自定义一下mutableCopy 那么就必须遵守NSMutableCopying,并且实现 mutableCopyWithZone: 方法。
-(id)mutableCopyWithZone:(NSZone *)zone
{
    return s_urlAddress;
}
+ (id)mutableCopyWithZone:(struct _NSZone *)zone
{
    return s_urlAddress;
}

- (void) setTestMode:(NSString *)testMode
{
    if ([testMode isEqualToString:@"1"])
    {
        _url_prefix = @"我是测试";
    }else if ([testMode isEqualToString:@"2"])
    {
        _url_prefix = @"我是正式";
    }
    
    _url_homeUrl=[NSString stringWithFormat:@"%@首页接口",_url_prefix];
    _url_loginUrl=[NSString stringWithFormat:@"%@登录接口",_url_prefix];
    _url_registeredUrl=[NSString stringWithFormat:@"%@注册接口",_url_prefix];

}

//域名
-(NSString *)getPrefix{
    return _url_prefix;
}

-(NSString *)getHomeUrl{
    return _url_homeUrl;
}
-(NSString *)getLoginUrl{
    return _url_loginUrl;
}
-(NSString *)getRegisteredUrl{
    return _url_registeredUrl;
}

@end
