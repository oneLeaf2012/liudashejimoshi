//
//  main.m
//  singletonDemo
//
//  Created by shuzhenguo on 2017/7/25.
//  Copyright © 2017年 shuzhenguo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "UrlAddress.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        
      /*
        UrlAddress *s1 = [[UrlAddress alloc]init];
        UrlAddress *s2 = [UrlAddress getInstance];
        UrlAddress *s3 = [[UrlAddress alloc]init];
        UrlAddress *s4 = [UrlAddress getInstance];
        UrlAddress *s5 = [s4 copy];
        
       NSLog(@"s1----%p \ns2----%p \ns3----%p \ns4----%p \ns5----%p",s1,s2,s3,s4, s5);
        
    */
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
