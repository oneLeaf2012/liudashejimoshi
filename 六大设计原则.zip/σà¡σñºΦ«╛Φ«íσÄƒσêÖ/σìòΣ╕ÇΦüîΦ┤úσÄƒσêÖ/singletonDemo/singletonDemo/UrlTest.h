//
//  UrlTest.h
//  singletonDemo
//
//  Created by shuzhenguo on 2017/7/25.
//  Copyright © 2017年 shuzhenguo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseUrl.h"
//@interface UrlTest : NSObject

@interface UrlTest : BaseUrl

- (NSString *) getTest;


- (NSString *) getLoginUrl;
- (NSString *) getHomeUrl;

@end
