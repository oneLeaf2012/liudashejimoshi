//
//  UrlTest.m
//  singletonDemo
//
//  Created by shuzhenguo on 2017/7/25.
//  Copyright © 2017年 shuzhenguo. All rights reserved.
//

#import "UrlTest.h"

@implementation UrlTest

- (NSString *) getTest{
return @"我是测试url";
}



- (NSString *) getLoginUrl{
return @"我是登录测试接口";

}

- (NSString *) getHomeUrl{
    return @"我是首页测试接口";

}

//- (NSString *) getLoginTest{
//    return @"我是登录测试接口";
//}

@end
