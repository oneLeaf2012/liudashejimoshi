//
//  UrlLoginTest.m
//  singletonDemo
//
//  Created by shuzhenguo on 2017/7/25.
//  Copyright © 2017年 shuzhenguo. All rights reserved.
//

#import "UrlLoginTest.h"

@implementation UrlLoginTest
- (NSString *) getLoginTest{
return @"我是登录测试接口";
}


@end
