//
//  UrlAddress.h
//  QYSDKCommon
//
//  Created by shuzhenguo on 14-4-15.
//  Copyright (c) 2014年 shuzhenguo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UrlAddress : NSObject

+ (UrlAddress*) getInstance;
//环境设置
- (void) setTestMode:(NSString *)testMode;
////域名
-(NSString *)getPrefix;

-(NSString *)getHomeUrl;
-(NSString *)getLoginUrl;
-(NSString *)getRegisteredUrl;




@end
