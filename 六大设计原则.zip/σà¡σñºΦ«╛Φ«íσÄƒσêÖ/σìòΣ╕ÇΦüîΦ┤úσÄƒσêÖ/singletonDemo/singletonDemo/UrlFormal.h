//
//  UrlFormal.h
//  singletonDemo
//
//  Created by shuzhenguo on 2017/7/25.
//  Copyright © 2017年 shuzhenguo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseUrl.h"

@interface UrlFormal : BaseUrl
- (NSString *) getFormal;

- (NSString *) getLoginUrl;
- (NSString *) getHomeUrl;

@end
