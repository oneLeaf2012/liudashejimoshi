//
//  UrlFit.m
//  singletonDemo
//
//  Created by shuzhenguo on 2017/7/25.
//  Copyright © 2017年 shuzhenguo. All rights reserved.
//

#import "UrlFit.h"

@implementation UrlFit

- (NSString *) setTestMode:(NSString *)testMode  name:(NSString *)name{
    
    if ([testMode isEqualToString:@"1"]) {
        if ([name isEqualToString:@"home"]) {
            return @"我为首页测试接口";
        }else if ([name isEqualToString:@"login"]){
            return @"我是登录测试接口";
        }else if ([name isEqualToString:@"registered"]){
            return @"我是注册测试接口";
        }
        
        
        
    }else if ([testMode isEqualToString:@"2"]){
        if ([name isEqualToString:@"home"]) {
            return @"我为首页正式接口";
        }else if ([name isEqualToString:@"login"]){
            return @"我是登录正式接口";
        }else if ([name isEqualToString:@"registered"]){
            return @"我是注册正式接口";
        }
        
    }
    return nil;
}

@end
