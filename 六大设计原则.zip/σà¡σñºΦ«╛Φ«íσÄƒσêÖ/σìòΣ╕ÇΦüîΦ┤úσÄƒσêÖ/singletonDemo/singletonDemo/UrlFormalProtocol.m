//
//  UrlFormalProtocol.m
//  singleDemo
//
//  Created by shuzhenguo on 2017/7/25.
//  Copyright © 2017年 shuzhenguo. All rights reserved.
//

#import "UrlFormalProtocol.h"

@implementation UrlFormalProtocol

- (NSString *) getLoginUrl{
    return @"我是登录正式接口";
}

- (NSString *) getHomeUrl{
    return @"我是首页正式接口";
}

@end
