//
//  ViewController.m
//  singletonDemo
//
//  Created by shuzhenguo on 2017/7/25.
//  Copyright © 2017年 shuzhenguo. All rights reserved.
//

#import "ViewController.h"
#import "UrlTest.h"
#import "UrlFormal.h"
#import "UrlLoginTest.h"
#import "UrlHomeTest.h"
#import "UrlRegisteredTest.h"
#import "UrlFit.h"
#import "UrlAddress.h"
#import "BaseUrl.h"


#import "BaseUrlProtocol.h"
#import "UrlTestProtocol.h"
#import "UrlFormalProtocol.h"

typedef id<BaseUrlProtocol> BaseUrlProtocol;

/*
 IOS设计模式的六大设计原则之单一职责原则(SRP,Single Responsibility Principle)
 定义
 
 　　就一个类而言，应该仅有一个引起它变化的原因。
 
 定义解读
 
 　　这是六大原则中最简单的一种，通俗点说，就是不存在多个原因使得一个类发生变化，也就是一个类只负责一种职责的工作。
 
 优点
 
 类的复杂度降低，一个类只负责一个功能，其逻辑要比负责多项功能简单的多；
 类的可读性增强，阅读起来轻松；
 可维护性强，一个易读、简单的类自然也容易维护；
 变更引起的风险降低，变更是必然的，如果单一职责原则遵守的好，当修改一个功能时，可以显著降低对其他功能的影响。
 
 */
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    
    
//    //当我们项目需要测试环境的时候，
//    //我们只获取一个测试的，这个类只做一个职责的工作
//    UrlTest *test=[[UrlTest alloc]init];
//    NSLog(@"getTest--%@",[test getTest]);
//    
//    
//    //当我们项目需要正式环境的时候，
//    //我们只获取一个测试的，这个类只做一个职责的工作
//    UrlFormal *formal=[[UrlFormal  alloc]init];
//    NSLog(@"getFormal--%@",[formal getFormal]);
//    
//    
//    //　遵循单一职责原则。分别建立两个类UrlTest、UrlFormal，使UrlTest完成测试职责，UrlFormal完成职责正式职责。这样，当修改类UrlTest时，不会使职责正式URL发生故障风险；同理，当修改UrlFormal时，也不会使职责测试URL发生故障风险。
//    
//    //-----------------------------------------------------------------------------------------------------------------------
//    
//    
//    //在做项目中，我们会有很多个接口 ，比如登录，注册，首页列表  等等。我们拿所有为测试接口为例
//    //现在呢，项目需要登录，和首页的接口
//    
//    UrlLoginTest *loginTest=[[UrlLoginTest alloc]init];
//    UrlHomeTest *urlHome=[[UrlHomeTest alloc]init];
//    UrlRegisteredTest *registered=[[UrlRegisteredTest alloc]init];
//    [loginTest getLoginTest];
//    [urlHome getHomeTest];
//    [registered getRegisteredTest];
//    
//    
//    //看完上面，确实是遵循了单一职责原则，随着项目的接口增多，对应要建立很多个类，再加上测试，正式俩套切换 更改量实在是太大。。。
//    
//    
//    /*优化方法一。
//     我们新建UrlFit类，增加  - (NSString *) setTestMode:(NSString *)testMode  name:(NSString *)name; testMode 来标示切换正式测试，name为接口的名字, testMode为1是测试，为2为正式
//     */
//    
//    UrlFit *urlfit=[[UrlFit alloc]init];
//    
//    NSLog(@"home--%@",[urlfit setTestMode:@"1" name:@"home"]);
//    NSLog(@"login--%@",[urlfit setTestMode:@"1" name:@"login"]);
//    NSLog(@"registered--%@",[urlfit setTestMode:@"1" name:@"registered"]);
//    
//    
//    
//    NSLog(@"home--%@",[urlfit setTestMode:@"2" name:@"home"]);
//    NSLog(@"login--%@",[urlfit setTestMode:@"2" name:@"login"]);
//    NSLog(@"registered--%@",[urlfit setTestMode:@"2" name:@"registered"]);
//    
//    //这个比上面的会方便的多，但是在这已经违背了单一职责原则，并且不太符合需求，每个接口都需要填充正式，测试，切换时工作量大（可能会存在遗漏或者疏忽）。
//    
//    /*
//     *优化方法二
//     
//     我们新建UrlAddress 类。分析，各个模块都需要调用，则此类写为单例最为合适，此单例按以上给出的需求，
//     
//     需要建立
//     
//     - (void) setTestMode:(NSString *)testMode;       切换测试正式测试环境
//     -(NSString *)getPrefix;                          url前缀相同的则提出来
//     -(NSString *)getHomeUrl;                         获取首页的接口
//     -(NSString *)getLoginUrl;                        获取登录的接口
//     -(NSString *)getRegisteredUrl;                   获取注册的接口
//     */
//    
//    
//    
//    UrlAddress *urlAddress=[UrlAddress getInstance];
//    NSLog(@"getPrefix--%@",[urlAddress getPrefix]);
//    NSLog(@"getHomeUrl--%@",[urlAddress getHomeUrl]);
//    NSLog(@"getLoginUrl--%@",[urlAddress getLoginUrl]);
//    NSLog(@"getRegisteredUrl--%@",[urlAddress getRegisteredUrl]);
    
    
    //通过继承的方式来显示切换正式，测试的环境，来达到单一原则
    BaseUrl *base=[[UrlTest alloc]init];
    NSLog(@"UrlTest--%@",[base  getHomeUrl] );
    NSLog(@"UrlTest---%@",[base  getLoginUrl] );
    BaseUrl *base1=[[UrlFormal alloc]init];
    NSLog(@"UrlFormal---%@",[base1  getHomeUrl] );
    NSLog(@"UrlFormal--%@",[base1  getLoginUrl] );

    
    
    //通过协议的方式切换正式，测试的环境，来达到单一原则
    BaseUrlProtocol basePrTest=[[UrlTestProtocol alloc]init];
    NSLog(@"UrlTestProtocol---%@",[basePrTest  getHomeUrl] );
    NSLog(@"UrlTestProtocol--%@",[basePrTest  getLoginUrl] );
    BaseUrlProtocol basePrFormal=[[UrlFormalProtocol alloc]init];
    NSLog(@"UrlFormalProtocol---%@",[basePrFormal  getHomeUrl] );
    NSLog(@"UrlFormalProtocol--%@",[basePrFormal  getLoginUrl] );

    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
