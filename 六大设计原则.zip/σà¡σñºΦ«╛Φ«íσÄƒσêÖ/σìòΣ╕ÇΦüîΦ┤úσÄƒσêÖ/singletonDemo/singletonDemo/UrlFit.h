//
//  UrlFit.h
//  singletonDemo
//
//  Created by shuzhenguo on 2017/7/25.
//  Copyright © 2017年 shuzhenguo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UrlFit : NSObject
- (NSString *) setTestMode:(NSString *)testMode  name:(NSString *)name;
@end
