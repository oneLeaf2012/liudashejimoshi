//
//  Staff.m
//  SingleResponsibilityPrinciple
//
//  Created by ligf on 13-11-26.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import "Staff.h"

@implementation Staff

- (void)calculateSalary:(NSString *)name
{
    NSLog(@"%@员工的工资是100",name);
}

@end
