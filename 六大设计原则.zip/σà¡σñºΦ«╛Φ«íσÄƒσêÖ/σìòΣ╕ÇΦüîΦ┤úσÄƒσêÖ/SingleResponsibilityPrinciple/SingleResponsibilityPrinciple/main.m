//
//  main.m
//  单一职责原则
//
//  Created by ligf on 13-11-26.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Employee.h"
#import "Director.h"
#import "Manager.h"
#import "Staff.h"

int main(int argc, const char * argv[])
{
    @autoreleasepool {
        /* 原始方式
        Employee *employee = [[Employee alloc] init];
        [employee calculateSalary:@"张三"];
        [employee calculateSalary:@"李四"];
        [employee release];
         */
        
        /* 遵循单一职责原则的方式
        Director *director = [[Director alloc] init];
        Manager *manager = [[Manager alloc] init];
        Staff *staff = [[Staff alloc] init];
        
        [director calculateSalary:@"张三"];
        [manager calculateSalary:@"李四"];
        [staff calculateSalary:@"王五"];
        
        [director release];
        [manager release];
        [staff release];
         */
        
        /* 修改calculateSalary方法的方式
        Employee *employee = [[Employee alloc] init];
        [employee calculateSalary:@"张三" flag:@"Director"];
        [employee calculateSalary:@"李四" flag:@"Manager"];
        [employee calculateSalary:@"王五" flag:@"Staff"];
        [employee release];
         */
        
        /* 新增方法的方式*/
        Employee *employee = [[Employee alloc] init];
        [employee directorCalculateSalary:@"张三"];
        [employee managerCalculateSalary:@"李四"];
        [employee staffCalculateSalary:@"王五"];
        [employee release];
    }
    return 0;
}

