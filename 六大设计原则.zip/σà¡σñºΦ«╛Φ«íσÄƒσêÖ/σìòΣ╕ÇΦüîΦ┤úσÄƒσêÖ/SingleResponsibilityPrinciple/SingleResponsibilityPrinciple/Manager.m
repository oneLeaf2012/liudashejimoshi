//
//  Manager.m
//  SingleResponsibilityPrinciple
//
//  Created by ligf on 13-11-26.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import "Manager.h"

@implementation Manager

- (void)calculateSalary:(NSString *)name
{
    NSLog(@"%@经理的工资是1000",name);
}

@end
