//
//  Employee.h
//  SingleResponsibilityPrinciple
//
//  Created by ligf on 13-11-26.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Employee : NSObject

// 计算工资
- (void)calculateSalary:(NSString *)name;

// 计算工资,增加员工岗位的标识(Director:总监;Manager:经理;Staff:普通员工)
- (void)calculateSalary:(NSString *)name flag:(NSString *)flag;

// 总监工资计算
- (void)directorCalculateSalary:(NSString *)name;

// 经理工资计算
- (void)managerCalculateSalary:(NSString *)name;

// 普通员工工资计算
- (void)staffCalculateSalary:(NSString *)name;

@end
