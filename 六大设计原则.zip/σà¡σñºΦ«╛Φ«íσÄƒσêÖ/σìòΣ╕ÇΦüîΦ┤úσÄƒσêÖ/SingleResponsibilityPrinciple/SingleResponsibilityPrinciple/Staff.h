//
//  Staff.h
//  SingleResponsibilityPrinciple
//
//  Created by ligf on 13-11-26.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Staff : NSObject

// 计算工资
- (void)calculateSalary:(NSString *)name;

@end
