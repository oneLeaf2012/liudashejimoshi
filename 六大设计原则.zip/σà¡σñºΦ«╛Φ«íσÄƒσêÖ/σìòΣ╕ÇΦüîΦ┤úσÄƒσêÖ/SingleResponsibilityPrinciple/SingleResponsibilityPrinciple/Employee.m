//
//  Employee.m
//  SingleResponsibilityPrinciple
//
//  Created by ligf on 13-11-26.
//  Copyright (c) 2013年 yonyou. All rights reserved.
//

#import "Employee.h"

@implementation Employee

- (void)calculateSalary:(NSString *)name
{
    NSLog(@"%@的工资是100",name);
}

// 计算工资,增加员工岗位的标识(Director:总监;Manager:经理;Staff:普通员工)
- (void)calculateSalary:(NSString *)name flag:(NSString *)flag
{
    if ([flag isEqualToString:@"Director"])
    {
        NSLog(@"%@总监的工资是10000",name);
    }
    else if ([flag isEqualToString:@"Manager"])
    {
        NSLog(@"%@经理的工资是1000",name);
    }
    else if ([flag isEqualToString:@"Staff"])
    {
        NSLog(@"%@员工的工资是100",name);
    }
}

// 总监工资计算
- (void)directorCalculateSalary:(NSString *)name
{
    NSLog(@"%@总监的工资是10000",name);
}

// 经理工资计算
- (void)managerCalculateSalary:(NSString *)name
{
    NSLog(@"%@经理的工资是1000",name);
}

// 普通员工工资计算
- (void)staffCalculateSalary:(NSString *)name
{
    NSLog(@"%@员工的工资是100",name);
}

@end
